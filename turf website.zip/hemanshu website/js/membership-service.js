// Membership Service - TurfBook Web App (Compat SDK)

var MEMBERSHIP_PLANS = [
    {
        id: 'silver', name: 'Silver', price: 499, period: '/month', color: '#9E9E9E', icon: '🥈',
        benefits: ['5% discount on all bookings', '10% off surge pricing', 'Booking history & analytics', 'Priority email support']
    },
    {
        id: 'gold', name: 'Gold', price: 999, period: '/month', color: '#F59E0B', icon: '🥇', popular: true,
        benefits: ['10% discount on all bookings', '20% off surge pricing', 'Peak hour access', 'Priority booking queue', 'Free cancellation (24h)', 'Dedicated support']
    },
    {
        id: 'platinum', name: 'Platinum', price: 1999, period: '/month', color: '#7C3AED', icon: '👑',
        benefits: ['20% discount on all bookings', '35% off surge pricing', 'Peak hour priority access', 'Highest booking priority', 'Free cancellation anytime', 'Exclusive tournaments access', 'VIP lounge access', '24/7 premium support']
    },
];

async function upgradeMembership(userId, tier) {
    try {
        await db.collection('users').doc(userId).update({ membership: tier, membershipUpdatedAt: firebase.firestore.FieldValue.serverTimestamp() });
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}
