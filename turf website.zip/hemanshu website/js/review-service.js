// Review Service - TurfBook Web App (Compat SDK)

async function addReview(turfId, reviewData) {
    try {
        var ref = await db.collection('reviews').add(
            Object.assign({ turfId: turfId, createdAt: firebase.firestore.FieldValue.serverTimestamp() }, reviewData)
        );
        await updateTurfRating(turfId);
        return { success: true, id: ref.id };
    } catch (error) { return { success: false, error: error.message }; }
}

async function getReviews(turfId) {
    try {
        var snap = await db.collection('reviews').where('turfId', '==', turfId).orderBy('createdAt', 'desc').get();
        var reviews = [];
        snap.forEach(function (d) { reviews.push(Object.assign({ id: d.id }, d.data())); });
        return reviews;
    } catch (e) { return []; }
}

async function updateReview(reviewId, turfId, oldRating, newRating, newComment) {
    try {
        await db.collection('reviews').doc(reviewId).update({ rating: newRating, comment: newComment, updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
        await updateTurfRating(turfId);
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}

async function deleteReview(reviewId, turfId) {
    try {
        await db.collection('reviews').doc(reviewId).delete();
        await updateTurfRating(turfId);
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}

async function updateTurfRating(turfId) {
    var snap = await db.collection('reviews').where('turfId', '==', turfId).get();
    if (snap.empty) return;
    var total = 0, count = 0;
    snap.forEach(function (d) { total += d.data().rating || 0; count++; });
    var avg = parseFloat((total / count).toFixed(1));
    await db.collection('turfs').doc(turfId).update({ rating: avg, reviewCount: count });
}
