// Slot Engine - TurfBook Web App (Compat SDK)

function generateTimeSlots() {
    var slots = [];
    for (var h = 6; h <= 22; h++) {
        var start = h.toString().padStart(2, '0') + ':00';
        var end = (h + 1).toString().padStart(2, '0') + ':00';
        slots.push({ time: start + ' - ' + end, hour: h });
    }
    return slots;
}

async function createSlotsForDate(turfId, date, sports) {
    var timeSlots = generateTimeSlots();
    for (var si = 0; si < sports.length; si++) {
        for (var ti = 0; ti < timeSlots.length; ti++) {
            var sport = sports[si], slot = timeSlots[ti];
            var slotId = turfId + '_' + date + '_' + sport + '_' + slot.hour;
            var slotDoc = await db.collection('slots').doc(slotId).get();
            if (!slotDoc.exists) {
                await db.collection('slots').doc(slotId).set({
                    turfId: turfId, date: date, sport: sport,
                    time: slot.time, hour: slot.hour,
                    status: 'available', userId: null, bookingId: null,
                    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                });
            }
        }
    }
}

function listenToSlots(turfId, date, sport, callback) {
    return db.collection('slots')
        .where('turfId', '==', turfId)
        .where('date', '==', date)
        .where('sport', '==', sport)
        .orderBy('hour', 'asc')
        .onSnapshot(function (snapshot) {
            var slots = [];
            snapshot.forEach(function (d) { slots.push(Object.assign({ id: d.id }, d.data())); });
            callback(slots);
        });
}

async function getRelatedSlotIds(turfId, date, hour) {
    try {
        var snap = await db.collection('slots')
            .where('turfId', '==', turfId)
            .where('date', '==', date)
            .where('hour', '==', hour).get();
        return snap.docs.map(function (d) { return { id: d.id, ref: d.ref, data: d.data() }; });
    } catch (e) { return []; }
}

async function bookSlot(slotIds, userId, bookingData) {
    try {
        var slotsToProcess = Array.isArray(slotIds) ? slotIds : [slotIds];
        await db.runTransaction(async function (transaction) {
            var updates = [];
            for (var i = 0; i < slotsToProcess.length; i++) {
                var id = slotsToProcess[i];
                var ref = db.collection('slots').doc(id);
                var snap = await transaction.get(ref);
                if (!snap.exists) throw new Error('Slot ' + id + ' does not exist');
                var originalData = snap.data();
                var isAvailable = originalData.status === 'available';
                var isLockedByMe = originalData.status === 'payment_pending' && originalData.userId === userId;
                if (!isAvailable && !isLockedByMe) throw new Error('Slot ' + originalData.time + ' is no longer available');
                var related = await getRelatedSlotIds(originalData.turfId, originalData.date, originalData.hour);
                var newStatus = bookingData.paymentMethod === 'pay_later' ? 'reserved' : 'booked';
                for (var r = 0; r < related.length; r++) {
                    updates.push({
                        ref: related[r].ref, data: {
                            status: newStatus, userId: userId, bookingId: bookingData.bookingId,
                            updatedAt: firebase.firestore.FieldValue.serverTimestamp(), expiresAt: null, bookedSport: originalData.sport
                        }
                    });
                }
            }
            for (var u = 0; u < updates.length; u++) transaction.update(updates[u].ref, updates[u].data);
        });
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}

async function lockSlots(slotIds, userId) {
    try {
        var slotsToLock = Array.isArray(slotIds) ? slotIds : [slotIds];
        var expiresAt = new Date();
        expiresAt.setMinutes(expiresAt.getMinutes() + 3);
        await db.runTransaction(async function (transaction) {
            var updates = [];
            for (var i = 0; i < slotsToLock.length; i++) {
                var ref = db.collection('slots').doc(slotsToLock[i]);
                var snap = await transaction.get(ref);
                if (!snap.exists) throw new Error('Slot does not exist');
                if (snap.data().status !== 'available') throw new Error('Slot already taken');
                var data = snap.data();
                var related = await getRelatedSlotIds(data.turfId, data.date, data.hour);
                for (var r = 0; r < related.length; r++) {
                    updates.push({
                        ref: related[r].ref, data: {
                            status: 'payment_pending', userId: userId,
                            expiresAt: firebase.firestore.Timestamp.fromDate(expiresAt),
                            updatedAt: firebase.firestore.FieldValue.serverTimestamp(), bookedSport: data.sport
                        }
                    });
                }
            }
            for (var u = 0; u < updates.length; u++) transaction.update(updates[u].ref, updates[u].data);
        });
        return { success: true, expiresAt: expiresAt };
    } catch (error) { return { success: false, error: error.message }; }
}

async function releaseSlots(slotIds, userId) {
    try {
        var slotsToRelease = Array.isArray(slotIds) ? slotIds : [slotIds];
        for (var i = 0; i < slotsToRelease.length; i++) {
            var snap = await db.collection('slots').doc(slotsToRelease[i]).get();
            if (snap.exists && snap.data().status === 'payment_pending' && snap.data().userId === userId) {
                var data = snap.data();
                var related = await getRelatedSlotIds(data.turfId, data.date, data.hour);
                for (var r = 0; r < related.length; r++) {
                    await related[r].ref.update({ status: 'available', userId: null, expiresAt: null, updatedAt: firebase.firestore.FieldValue.serverTimestamp(), bookedSport: null });
                }
            }
        }
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}

async function cleanupExpiredSlots() {
    try {
        var now = firebase.firestore.Timestamp.now();
        var snap = await db.collection('slots').where('status', '==', 'payment_pending').where('expiresAt', '<=', now).get();
        if (snap.empty) return { success: true, count: 0 };
        var batch = [];
        for (var i = 0; i < snap.docs.length; i++) {
            var data = snap.docs[i].data();
            var related = await getRelatedSlotIds(data.turfId, data.date, data.hour);
            for (var r = 0; r < related.length; r++) {
                batch.push(related[r].ref.update({ status: 'available', userId: null, expiresAt: null, updatedAt: firebase.firestore.FieldValue.serverTimestamp(), bookedSport: null }));
            }
        }
        await Promise.all(batch);
        return { success: true, count: snap.size };
    } catch (error) { return { success: false, error: error.message }; }
}

async function blockSlot(slotId) {
    try {
        var snap = await db.collection('slots').doc(slotId).get();
        if (!snap.exists) throw new Error('Slot does not exist');
        var data = snap.data();
        var related = await getRelatedSlotIds(data.turfId, data.date, data.hour);
        for (var r = 0; r < related.length; r++) {
            await related[r].ref.update({ status: 'blocked', userId: null, bookingId: null, updatedAt: firebase.firestore.FieldValue.serverTimestamp(), bookedSport: 'maintenance' });
        }
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}

async function unblockSlot(slotId) {
    try {
        var snap = await db.collection('slots').doc(slotId).get();
        if (!snap.exists) throw new Error('Slot does not exist');
        var data = snap.data();
        var related = await getRelatedSlotIds(data.turfId, data.date, data.hour);
        for (var r = 0; r < related.length; r++) {
            await related[r].ref.update({ status: 'available', userId: null, bookingId: null, updatedAt: firebase.firestore.FieldValue.serverTimestamp(), bookedSport: null });
        }
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}

async function resetSlot(slotId) {
    try {
        var snap = await db.collection('slots').doc(slotId).get();
        if (!snap.exists) throw new Error('Slot does not exist');
        var data = snap.data();
        var related = await getRelatedSlotIds(data.turfId, data.date, data.hour);
        for (var r = 0; r < related.length; r++) {
            await related[r].ref.update({ status: 'available', userId: null, bookingId: null, expiresAt: null, updatedAt: firebase.firestore.FieldValue.serverTimestamp(), bookedSport: null });
        }
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}

async function approveReservedSlot(slotId) {
    try {
        await db.collection('slots').doc(slotId).update({ status: 'booked', updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}

async function rejectReservedSlot(slotId) {
    try {
        await db.collection('slots').doc(slotId).update({ status: 'available', userId: null, bookingId: null, updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}
