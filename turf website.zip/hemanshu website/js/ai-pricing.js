// AI Pricing Service - TurfBook Web App (Compat SDK)

async function analyzePeakHours(turfId) {
    try {
        var snap = await db.collection('bookings')
            .where('turfId', '==', turfId)
            .where('status', 'in', ['confirmed', 'completed']).get();
        var hourCounts = {};
        snap.forEach(function (doc) {
            var data = doc.data();
            if (data.hour !== undefined) hourCounts[data.hour] = (hourCounts[data.hour] || 0) + 1;
        });
        var counts = Object.values(hourCounts);
        if (counts.length === 0) return { peakHours: [], surgeFactors: {} };
        var avg = counts.reduce(function (a, b) { return a + b; }, 0) / counts.length;
        var peakHours = [], surgeFactors = {};
        for (var hour in hourCounts) {
            var h = parseInt(hour), ratio = hourCounts[hour] / avg;
            if (ratio > 1.3) { peakHours.push(h); surgeFactors[h] = Math.min(1.5, 1.0 + (ratio - 1) * 0.25); }
            else { surgeFactors[h] = 1.0; }
        }
        return { peakHours: peakHours, surgeFactors: surgeFactors };
    } catch (e) { return { peakHours: [], surgeFactors: {} }; }
}

function getDefaultPeakHours() {
    return {
        peakHours: [17, 18, 19, 20],
        surgeFactors: { 6: 1.0, 7: 1.0, 8: 1.0, 9: 1.0, 10: 1.0, 11: 1.0, 12: 1.0, 13: 1.0, 14: 1.0, 15: 1.0, 16: 1.1, 17: 1.2, 18: 1.3, 19: 1.4, 20: 1.3, 21: 1.15, 22: 1.0 },
    };
}

function getSurgeForHour(surgeFactors, hour) { return surgeFactors[hour] || 1.0; }
function isPeakHour(peakHours, hour) { return peakHours.indexOf(hour) !== -1; }

async function getRevenueAnalytics() {
    try {
        var now = new Date();
        var weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        var monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        var snap = await db.collection('bookings').where('status', 'in', ['confirmed', 'completed']).get();
        var weeklyRevenue = 0, monthlyRevenue = 0, totalRevenue = 0, totalBookings = 0;
        var sportCounts = {}, hourRevenues = {};
        snap.forEach(function (doc) {
            var data = doc.data();
            var amount = data.totalAmount || data.amount || 0;
            var createdAt = data.createdAt && data.createdAt.toDate ? data.createdAt.toDate() : new Date();
            totalRevenue += amount; totalBookings++;
            if (createdAt >= weekAgo) weeklyRevenue += amount;
            if (createdAt >= monthAgo) monthlyRevenue += amount;
            if (data.sport) sportCounts[data.sport] = (sportCounts[data.sport] || 0) + 1;
            if (data.hour !== undefined) hourRevenues[data.hour] = (hourRevenues[data.hour] || 0) + amount;
        });
        var mostPopularSport = Object.entries(sportCounts).sort(function (a, b) { return b[1] - a[1]; })[0];
        var peakEarningTime = Object.entries(hourRevenues).sort(function (a, b) { return b[1] - a[1]; })[0];
        return {
            weeklyRevenue: weeklyRevenue, monthlyRevenue: monthlyRevenue, totalRevenue: totalRevenue, totalBookings: totalBookings,
            mostPopularSport: mostPopularSport ? mostPopularSport[0] : 'N/A',
            peakEarningTime: peakEarningTime ? peakEarningTime[0] + ':00' : 'N/A'
        };
    } catch (e) {
        return { weeklyRevenue: 0, monthlyRevenue: 0, totalRevenue: 0, totalBookings: 0, mostPopularSport: 'N/A', peakEarningTime: 'N/A' };
    }
}
