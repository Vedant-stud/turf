// Mail Service - TurfBook Web App
var APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwFe90PZLDsXPmDixNUFKIKxxj3tBX1uuv27zgiztpvw__5tzHyI1L8KU-3etuiMGBY/exec';

async function sendEmail(toEmail, subject, htmlContent) {
    try {
        await fetch(APPS_SCRIPT_URL, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ toEmail: toEmail, subject: subject, htmlContent: htmlContent }) });
        return { success: true };
    } catch (error) { return { success: false, error: error.message }; }
}

async function sendBookingReceivedEmail(data) {
    var subject = '📥 Booking Received: #' + data.bookingId;
    var html = '<div style="font-family:sans-serif;padding:20px;color:#333"><h1 style="color:#4CAF50">Booking Received!</h1><p>Hi ' + data.userName + ',</p><p>We received your booking for <b>' + data.turfName + '</b>.</p><div style="background:#f3f4f6;padding:15px;border-radius:8px;margin:20px 0"><p><b>Booking ID:</b> #' + data.bookingId + '</p><p><b>Sport:</b> ' + data.sport + '</p><p><b>Date:</b> ' + data.date + '</p><p><b>Time:</b> ' + data.time + '</p><p><b>Amount:</b> ₹' + data.totalAmount + '</p></div><p>Best regards,<br>Team TurfBook</p></div>';
    return sendEmail(data.userEmail, subject, html);
}

async function sendBookingConfirmedEmail(data) {
    var subject = '✅ Booking Confirmed: #' + data.bookingId;
    var html = '<div style="font-family:sans-serif;padding:20px;color:#333"><h1 style="color:#10B981">Booking Confirmed!</h1><p>Great news ' + data.userName + '!</p><p>Your booking for <b>' + data.turfName + '</b> has been confirmed.</p><div style="background:#ecfdf5;padding:15px;border-radius:8px;border:1px solid #10B981;margin:20px 0"><p><b>Booking ID:</b> #' + data.bookingId + '</p><p><b>Date:</b> ' + data.date + '</p><p><b>Time:</b> ' + data.time + '</p></div><p>See you at the turf!</p></div>';
    return sendEmail(data.userEmail, subject, html);
}
