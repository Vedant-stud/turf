// Auth helper module - TurfBook Web App (Compat SDK)

// Admin credentials (same as Android app)
var ADMIN_EMAIL = 'hemanshu@admin.com';
var ADMIN_PASSWORD = 'hemanshu';

function authGuard() {
    return new Promise(function (resolve) {
        auth.onAuthStateChanged(function (user) {
            if (!user) {
                var isAdminPage = window.location.pathname.includes('/admin/');
                window.location.href = isAdminPage ? '../index.html' : 'index.html';
                return;
            }
            resolve(user);
        });
    });
}

function adminGuard() {
    return new Promise(function (resolve) {
        auth.onAuthStateChanged(async function (user) {
            if (!user) { window.location.href = '../index.html'; return; }
            // Check admin by email match (same as Android app)
            if (user.email === ADMIN_EMAIL) {
                try {
                    var userDoc = await db.collection('users').doc(user.uid).get();
                    resolve({ user: user, userData: userDoc.data() });
                } catch (e) {
                    // If no user doc yet, create one for admin
                    var adminData = { uid: user.uid, name: 'Admin', email: ADMIN_EMAIL, phone: '', membership: 'none', isAdmin: true, role: 'admin', createdAt: firebase.firestore.FieldValue.serverTimestamp() };
                    await db.collection('users').doc(user.uid).set(adminData);
                    resolve({ user: user, userData: adminData });
                }
            } else {
                // Not admin, redirect to user home
                window.location.href = '../home.html';
            }
        });
    });
}

async function doLogin(email, password) {
    try {
        var cred = await auth.signInWithEmailAndPassword(email, password);
        // Check if user is admin by email (same as Android app)
        if (cred.user.email === ADMIN_EMAIL) {
            // Ensure admin user doc exists
            var adminDoc = await db.collection('users').doc(cred.user.uid).get();
            if (!adminDoc.exists()) {
                await db.collection('users').doc(cred.user.uid).set({
                    uid: cred.user.uid, name: 'Admin', email: ADMIN_EMAIL, phone: '',
                    membership: 'none', isAdmin: true, role: 'admin',
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                });
            }
            window.location.href = 'admin/dashboard.html';
        } else {
            window.location.href = 'home.html';
        }
        return { success: true };
    } catch (error) {
        return { success: false, error: getFriendlyError(error.code) };
    }
}

async function doRegister(email, password, extra) {
    try {
        var cred = await auth.createUserWithEmailAndPassword(email, password);
        await db.collection('users').doc(cred.user.uid).set({
            uid: cred.user.uid,
            name: extra.name || '',
            phone: extra.phone || '',
            email: extra.email || email,
            membership: 'none',
            isAdmin: false,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        });
        window.location.href = 'home.html';
        return { success: true };
    } catch (error) {
        return { success: false, error: getFriendlyError(error.code) };
    }
}

async function doLogout() {
    await auth.signOut();
    var isAdminPage = window.location.pathname.includes('/admin/');
    window.location.href = isAdminPage ? '../index.html' : 'index.html';
}

async function doForgotPassword(email) {
    try {
        await auth.sendPasswordResetEmail(email);
        showToast('Password reset email sent! Check your inbox.', 'success');
        return { success: true };
    } catch (error) {
        showToast(getFriendlyError(error.code), 'error');
        return { success: false, error: getFriendlyError(error.code) };
    }
}

async function getCurrentUserData() {
    var user = auth.currentUser;
    if (!user) return null;
    var userDoc = await db.collection('users').doc(user.uid).get();
    return { user: user, userData: userDoc.data() };
}

function getFriendlyError(code) {
    var map = {
        'auth/user-not-found': 'No account found with this email',
        'auth/wrong-password': 'Incorrect password',
        'auth/invalid-credential': 'Invalid email or password',
        'auth/email-already-in-use': 'An account already exists with this email',
        'auth/weak-password': 'Password must be at least 6 characters',
        'auth/invalid-email': 'Invalid email address',
        'auth/too-many-requests': 'Too many attempts. Please try again later',
    };
    return map[code] || 'An error occurred. Please try again.';
}

function showToast(message, type) {
    type = type || 'default';
    var existing = document.querySelector('.toast');
    if (existing) existing.remove();
    var toast = document.createElement('div');
    toast.className = 'toast toast-' + type;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(function () { toast.remove(); }, 3000);
}
