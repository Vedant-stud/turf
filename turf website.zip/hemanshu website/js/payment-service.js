// Payment Service - TurfBook Web App

var MEMBERSHIP_CONFIG = {
    none: { discount: 0, surgeDiscount: 0, label: 'Free', color: '#9CA3AF', priority: 1 },
    silver: { discount: 0.05, surgeDiscount: 0.10, label: 'Silver', color: '#9E9E9E', priority: 2 },
    gold: { discount: 0.10, surgeDiscount: 0.20, label: 'Gold', color: '#F59E0B', priority: 3 },
    platinum: { discount: 0.20, surgeDiscount: 0.35, label: 'Platinum', color: '#7C3AED', priority: 4 },
};

function calculateFinalPrice(basePrice, membershipTier, surgeFactor) {
    surgeFactor = surgeFactor || 1.0;
    var config = MEMBERSHIP_CONFIG[membershipTier] || MEMBERSHIP_CONFIG.none;
    var effectiveSurge = surgeFactor > 1.0 ? 1 + (surgeFactor - 1) * (1 - config.surgeDiscount) : 1.0;
    var surgedPrice = Math.round(basePrice * effectiveSurge);
    return Math.round(surgedPrice * (1 - config.discount));
}

var SPORTS_ICONS = { football: '⚽', cricket: '🏏', badminton: '🏸', tennis: '🎾', basketball: '🏀', volleyball: '🏐', default: '🏟️' };
