// Cloudinary Upload Service - TurfBook Web App
var CLOUD_NAME = 'dghnv64fu';
var UPLOAD_PRESET = 'turfimg';

async function uploadPaymentScreenshot(file) {
    try {
        var formData = new FormData();
        formData.append('file', file);
        formData.append('upload_preset', UPLOAD_PRESET);
        formData.append('folder', 'turfbook/payments');
        var response = await fetch('https://api.cloudinary.com/v1_1/' + CLOUD_NAME + '/image/upload', { method: 'POST', body: formData });
        var data = await response.json();
        if (data.secure_url) return { success: true, url: data.secure_url };
        throw new Error(data.error ? data.error.message : 'Upload failed');
    } catch (error) { return { success: false, error: error.message }; }
}
