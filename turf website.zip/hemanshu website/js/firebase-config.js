// Firebase Configuration - TurfBook Web App (Compat SDK)
// This uses the compat SDK which works with file:// protocol

const firebaseConfig = {
    apiKey: "AIzaSyB54XXUsgCb1oRceMaO3S9anqq3mGyATzQ",
    authDomain: "turf-f7769.firebaseapp.com",
    projectId: "turf-f7769",
    storageBucket: "turf-f7769.firebasestorage.app",
    messagingSenderId: "513414177489",
    appId: "1:513414177489:web:b2fcbcf022dec656f0dbf0",
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
